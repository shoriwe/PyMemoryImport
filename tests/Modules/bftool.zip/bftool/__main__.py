import bftool

if __name__ == "__main__":
    bftool.Runner().run()
