__all__ = ["WORDLIST_MODE", "ARGUMENTS_MODE"]


# Use wordlist mode
WORDLIST_MODE = 0
# Use arguments mode
ARGUMENTS_MODE = 1
